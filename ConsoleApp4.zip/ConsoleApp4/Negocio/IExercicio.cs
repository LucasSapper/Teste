﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp4.Negocio
{
    public interface IExercicio
    {
        string PalavraPalindromo(string palavra);

        string RetiradaCaixa(string valor);

        string OrdenacaoLista();
    }
}
