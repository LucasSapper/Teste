﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApp4.Negocio
{
    public class Exercicio : IExercicio
    {
        public string PalavraPalindromo(string palavra)
        {
            char[] arrPalavraReverse = palavra.ToCharArray();

            Array.Reverse(arrPalavraReverse);

            string palavraPalindromo = string.Empty;
            
            foreach (char c in arrPalavraReverse)
            {
                palavraPalindromo += c.ToString();
            }

            if (palavra.ToUpper() == palavraPalindromo.ToUpper())
                return "A palavra é palindromo";
            else
                return "A palavra NÃO é palindromo";
        }

        public string RetiradaCaixa(string valor)
        {
            string retornoSucesso = string.Empty;
            string retornoErro = "Informação inválida";
            int valorRetirada;

            if (int.TryParse(valor, out valorRetirada))
            {
                List<int> retornoLst = new List<int>();
                Helper hp = new Helper();

                retornoLst = hp.RetornoCaixa(valorRetirada);
                var cedulasLst = retornoLst.GroupBy(i => i);

                foreach(var cedulas in cedulasLst)
                {
                    if (string.IsNullOrEmpty(retornoSucesso))
                        retornoSucesso = cedulas.Count() + " notas de " + cedulas.Key;
                    else
                        retornoSucesso = retornoSucesso + " " + cedulas.Count() + " notas de " + cedulas.Key;
                }

                return retornoSucesso;
            }
            else
                return retornoErro;

        }

        public string OrdenacaoLista()
        {
            int[] listaInt = new int[5];
            int[] listaOrdenadaInt = new int[5];

            listaInt[0] = 10;
            listaInt[1] = 1;
            listaInt[2] = 50;
            listaInt[3] = 13;
            listaInt[4] = 7;


            for (int index = 0; index < 5; index++)
            {
                if (index == 0)
                    listaOrdenadaInt[index] = listaInt[index];

                if (index == 1)
                {

                    if (listaOrdenadaInt[index - 1] <= listaInt[index])
                        listaOrdenadaInt[index] = listaInt[index];
                    else
                    {
                        var numero = listaOrdenadaInt[index - 1];
                        listaOrdenadaInt[index - 1] = listaInt[index];
                        listaOrdenadaInt[index] = numero;
                    }

                }

            }




            return null;
        }

    }
}
