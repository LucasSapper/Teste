﻿using System;

namespace ConsoleApp4.Apresentacao
{
    class Program
    {
        static void Main(string[] args)
        {
            ExercicioApresentacao exercicio = new ExercicioApresentacao();

            Console.WriteLine("Digite a palavra para verificar se a mesma é palíndromo: ");
            var palavra = Console.ReadLine();
            Console.WriteLine(exercicio.PalavraPalindromo(palavra));

            Console.WriteLine("\n");

            Console.WriteLine("Digite o valor que deseja sacar: ");
            var valor = Console.ReadLine();
            Console.WriteLine(exercicio.RetiradaCaixa(valor));

            Console.WriteLine(exercicio.OrdenacaoLista());

        }
    }
}
