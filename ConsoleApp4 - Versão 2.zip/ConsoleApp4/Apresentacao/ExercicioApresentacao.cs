﻿using ConsoleApp4.Negocio;
using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp4.Apresentacao
{
    public class ExercicioApresentacao
    {
        private IExercicio _exercicio = new Exercicio();

        public string PalavraPalindromo (string palavra)
        {
            return _exercicio.PalavraPalindromo(palavra);
        }

        public string RetiradaCaixa(string valor)
        {
            return _exercicio.RetiradaCaixa(valor);
        }

        public string OrdenacaoLista()
        {
            return _exercicio.OrdenacaoLista();
        }
    }
}
