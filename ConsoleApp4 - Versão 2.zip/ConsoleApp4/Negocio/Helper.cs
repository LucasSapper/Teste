﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp4.Negocio
{
    public class Helper
    {
        public List<int> RetornoCaixa(int valor)
        {
            List<int> cedulasLst = new List<int>();
            int resto = valor;

            int notas100 = valor / 100;
            if (notas100 > 0)
            {
                for (int index = 1; index <= notas100; index++)
                {
                    int resto100 = valor - 100;
                    int[] restoCedulas = new int[5];
                    restoCedulas[0] = 50;
                    restoCedulas[1] = 20;
                    restoCedulas[2] = 10;
                    restoCedulas[3] = 5;
                    restoCedulas[4] = 2;

                    if (ValidarCedula(resto100, restoCedulas))
                    {
                        cedulasLst.AddRange(AdiconarCedulas(1, 100));
                        valor = resto100;
                        resto = valor;
                    }                  
                }                
            }

            int notas50 = resto / 50;
            if (notas50 > 0)
            {
                for (int index = 1; index <= notas50; index++)
                {
                    int resto50 = resto - 50;
                    int[] restoCedulas = new int[4];
                    restoCedulas[0] = 20;
                    restoCedulas[1] = 10;
                    restoCedulas[2] = 5;
                    restoCedulas[3] = 2;

                    if (ValidarCedula(resto50, restoCedulas))
                    {
                        cedulasLst.AddRange(AdiconarCedulas(1, 50));
                        resto = resto50;
                    }
                }
            }

            int notas20 = resto / 20;
            if (notas20 > 0)
            {
                for (int index = 1; index <= notas20; index++)
                {
                    int resto20 = resto - 20;
                    int[] restoCedulas = new int[3];
                    restoCedulas[0] = 10;
                    restoCedulas[1] = 5;
                    restoCedulas[2] = 2;

                    if (ValidarCedula(resto20, restoCedulas))
                    {
                        cedulasLst.AddRange(AdiconarCedulas(1, 20));
                        resto = resto20;
                    }
                }
            }

            int notas10 = resto / 10;
            if (notas10 > 0)
            {
                for (int index = 1; index <= notas10; index++)
                {
                    int resto10 = resto - 10;
                    int[] restoCedulas = new int[2];
                    restoCedulas[0] = 5;
                    restoCedulas[1] = 2;

                    if (ValidarCedula(resto10, restoCedulas))
                    {
                        cedulasLst.AddRange(AdiconarCedulas(1, 10));
                        resto = resto10;
                    }
                }
            }

            int notas5 = resto / 5;
            if (notas5 > 0)
            {
                for (int index = 1; index <= notas5; index++)
                {
                    int resto5 = resto - 5;
                    int[] restoCedulas = new int[1];
                    restoCedulas[0] = 2;

                    if (ValidarCedula(resto5, restoCedulas))
                    {
                        cedulasLst.AddRange(AdiconarCedulas(1, 5));
                        resto = resto5;
                    }
                }
            }

            int notas2 = resto / 2;
            if (notas2 > 0)
                cedulasLst.AddRange(AdiconarCedulas(notas2, 2));

            return cedulasLst;
        }


        public List<int> AdiconarCedulas(int quantidade, int valor)
        {
            List<int> retornoLst = new List<int>();

            for (int index = 1; index <= quantidade; index++)
            {
                retornoLst.Add(valor);
            }

            return retornoLst;
        }

        public bool ValidarCedula(int valor, int[] cedulasLst)
        {
            if (valor == 0)
                return true;

            foreach(var cedula in cedulasLst)
            {
                if (valor >= cedula)
                    return true;
            }
            
            return false;
        }
    }
}
