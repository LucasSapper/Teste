﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApp4.Negocio
{
    public class Exercicio : IExercicio
    {
        public string PalavraPalindromo(string palavra)
        {
            char[] arrPalavraReverse = palavra.ToCharArray();

            Array.Reverse(arrPalavraReverse);

            string palavraPalindromo = string.Empty;
            
            foreach (char c in arrPalavraReverse)
            {
                palavraPalindromo += c.ToString();
            }

            if (palavra.ToUpper() == palavraPalindromo.ToUpper())
                return "A palavra é palindromo";
            else
                return "A palavra NÃO é palindromo";
        }

        public string RetiradaCaixa(string valor)
        {
            string retornoSucesso = string.Empty;
            string retornoErro = "Informação inválida";
            int valorRetirada;

            if (int.TryParse(valor, out valorRetirada))
            {
                List<int> retornoLst = new List<int>();
                Helper hp = new Helper();

                retornoLst = hp.RetornoCaixa(valorRetirada);
                var cedulasLst = retornoLst.GroupBy(i => i);

                foreach(var cedulas in cedulasLst)
                {
                    if (string.IsNullOrEmpty(retornoSucesso))
                        retornoSucesso = cedulas.Count() + " notas de " + cedulas.Key;
                    else
                        retornoSucesso = retornoSucesso + ", " + cedulas.Count() + " notas de " + cedulas.Key;
                }

                return retornoSucesso;
            }
            else
                return retornoErro;

        }

        public string OrdenacaoLista()
        {
            string retorno = string.Empty;

            int[] listaInt = new int[5];
            listaInt[0] = 10;
            listaInt[1] = 1;
            listaInt[2] = 50;
            listaInt[3] = 13;
            listaInt[4] = 7;

            for (int index = 0; index < listaInt.Length; index++)
            {
                for (int indexB = 0; indexB < listaInt.Length - 1; indexB++)
                {
                    if (listaInt[indexB] > listaInt[indexB + 1])
                    {
                        int valor = listaInt[indexB];
                        listaInt[indexB] = listaInt[indexB + 1];
                        listaInt[indexB + 1] = valor;
                    }
                }
            }

            for (int index = 0; index < listaInt.Length; index++)
            {
                if (string.IsNullOrEmpty(retorno))
                    retorno = "Lista ordenada: " + listaInt[index].ToString() ;
                else
                    retorno += "," + listaInt[index];
            }
                        
            return retorno;
        }

    }
}
